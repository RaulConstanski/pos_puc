## Elaborar um algoritmo que solicita dois números ao usuário e exibe a soma
## destes números.
#ENTRADA
n1 = float(input("Digite o valor do primeiro numero, use . (ponto) como separador decimal: ", ))
n2 = float(input("Digite o valor do segundo numero, use . (ponto) como separador decimal: ", ))
#PROCESSAMENTO
soma = n1 + n2
#RESULTADO
print("A soma do primeiro com o segundo numero é:",soma)
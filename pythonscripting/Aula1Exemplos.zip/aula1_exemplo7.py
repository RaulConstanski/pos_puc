# Tratamento de erros
try:
    quantidade = int( input("Digite a quantidade: ") )
except:
    print("Quantidade inválida!")

print("Fim de programa")
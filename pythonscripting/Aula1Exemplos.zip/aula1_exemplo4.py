# Expressão aritmética
resultado = 8 * 7
print(f"\n\n\n{resultado}\n\n\n")

# Expressão lógica (booleana)
resultado2 = (10 + 4) < (2 * 90)
print(f"\n\n\n{resultado2}\n\n\n")
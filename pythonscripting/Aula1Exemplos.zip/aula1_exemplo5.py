

# Entrada
ano_nascimento = int(input("Que ano vc nasceu? "))

# Processamento
idade = 2024 - ano_nascimento

fez_niver = input("Vc já fez aniversário esse ano?(s/n) ")
if fez_niver == "n":
    idade = idade - 1

# if fez_niver == "s":
#  print("Já fez")

# Saída
print("Idade:", idade)
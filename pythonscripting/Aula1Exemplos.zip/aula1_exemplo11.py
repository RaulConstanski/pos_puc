# Contagem
print(1)
print(2)
print(3)
print(4)
print(5)
print(6)
print(7)
print(8)
print(9)
print(10)

print("*" * 20)

i = 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)
i = i + 1
print(i)

print("*" * 20)

i = 0
# 0 < 10
# 1 < 10
# 2 < 10
# ...
# 9 < 10
# 10 < 10
while i < 10:
    #   0 + 1
    #   1
    # i = 1
    i = i + 1
    print(i)
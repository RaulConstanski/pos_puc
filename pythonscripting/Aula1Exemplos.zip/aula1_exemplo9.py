nota1 = float( input("Digite nota 1: ") )
nota2 = float( input("Digite nota 2: ") )

media = (nota1 + nota2) / 2

# if media >= 7:
#     print("Aprovado!")

# if media >= 4:
#     if media < 7:
#         print("Exame Final")

# if media < 4:
#     print("Reprovado :(")

# 9.5 >= 7
# 6 >= 7
# 3.5 >= 7
if media >= 7 and media <= 10:
    print("Aprovado!")
#    6 >= 4
#    3.5 >= 4
elif media >= 4:
    print("Exame Final")
else:
    print("Reprovado :(")
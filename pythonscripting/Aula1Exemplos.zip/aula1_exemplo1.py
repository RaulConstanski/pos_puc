# variável = valor
# variável recebe o valor
# o valor é armazenado na variável
# = operador de atribuição
nome_produto = "Pipoqueira Popflix"
preco = 154.37
quantidade = 1
presente = True

print("Produto: ",nome_produto)
print("Preço: R$", preco)
print("Quantidade: ", quantidade)
print("É para presente? ", presente)
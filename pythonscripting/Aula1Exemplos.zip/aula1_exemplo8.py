nota1 = float( input("Digite nota 1: ") )
nota2 = float( input("Digite nota 2: ") )

# media = 9.5
# media = 6
media = (nota1 + nota2) / 2

#  9.5 >= 7
# 6 >= 7
if media >= 7:
    print("Aprovado!")
else:
    print("Reprovado :(")
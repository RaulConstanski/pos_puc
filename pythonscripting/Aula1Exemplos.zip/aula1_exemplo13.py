
nota1 = -1

# Enquanto a nota for inválida
while True:
    nota1 = float( input("Digite nota 1: ") )
    if (nota1 >= 0 and nota1 <=10):
        break
    else:
        print("Erro. Digite um númer entre 1 e 10.")

print("Finalmente!!!!")
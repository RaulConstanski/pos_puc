
nota1 = -1

# Enquanto a nota for inválida
while nota1 < 0 or nota1 > 10:
    nota1 = float( input("Digite nota 1: ") )

print("Finalmente!!!!")
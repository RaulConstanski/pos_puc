nota1 = float( input("Digite nota 1: ") )

#   7 < 0  or   7 > 10
if nota1 < 0 or nota1 > 10:
    print("Nota inválida")
else:
    print("Nota válida!")

#      (nota válida)
#         7 >= 0   and   7 <= 10
#         True     and   True
#               True
#  not          True
if not (nota1 >= 0 and nota1 <=10):
    print("Nota inválida")
else:
    print("Nota válida")
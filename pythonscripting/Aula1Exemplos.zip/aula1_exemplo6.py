# Entrada
nome_produto = input("Digite o nome do seu produto: ")
preco = float( input("Digite o preço do produto: ") )
quantidade = int( input("Digite a quantidade: ") )

# Processamento
subtotal = preco * quantidade

# Se o total dos produtos for menor que 100 reais, 
if subtotal < 100:
#    adicione 30 reais de frete
    subtotal = subtotal + 30

# Saída
print("Produto: ", nome_produto)
print(f"Preço R$ {preco:10.2f}")
print("Quantidade: ", quantidade)
print(f"Subtotal: R$ {subtotal:.2f}")
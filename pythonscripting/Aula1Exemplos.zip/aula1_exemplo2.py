# Entrada
nome_produto = input("Digite o nome do seu produto: ")
# floating point: forma finita de armazenar número com casas decimais
preco = float( input("Digite o preço do produto: ") )
quantidade = int( input("Digite a quantidade: ") )

# Processamento
# subtotal = "3999" * "1" -> Erro
# subtotal = 3999.0 * 1
subtotal = preco * quantidade

# Saída
print("Produto: ", nome_produto)
print(f"Preço R$ {preco:10.2f}")
print("Quantidade: ", quantidade)
print(f"Subtotal: R$ {subtotal:.2f}")
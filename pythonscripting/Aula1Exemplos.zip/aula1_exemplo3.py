# Elaborar um programa que peça ao usuário um número 
# e informe o quadrado deste número

# Entrada: peça ao usuário um número
numero = float( input("Digite um número: ") )

# Processamento: o quadrado deste número
resultado = numero * numero

# Saída: informe o quadrado deste número
print("O quadrado do número é", resultado)
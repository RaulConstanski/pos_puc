# funções
# int, input, print, append, len, extend
def saudacao():
    print("Bom dia!")

def saudacao2(nome):
    # nome = "Alberto Roberto"
    print(f"Bom dia {nome}!!!")

# saudacao()
# saudacao()
# saudacao()
# saudacao()
# saudacao()

# for _ in range(0,101):
#     saudacao()

saudacao2("Aberto Roberto")
pessoa = "Zé das Couves"
saudacao2(pessoa)

print("Alguma coisa", end = " ")
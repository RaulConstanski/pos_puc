# Set (Conjunto) -> tem apenas elementos únicos
categorias = ["horror", "comédia", "horror"]
print(categorias)

set_categorias = {"horror", "comédia", "horror"}
print(set_categorias)
# print(set_categorias[0]) <-- ERRO

for categoria in enumerate(set_categorias):
    print(categoria)


# Operações: união, interseção e diferença
outras_categorias = {"romance", "comédia", "ação"}

print(f"União: {set_categorias | outras_categorias}")
print(f"Interseção: {set_categorias & outras_categorias}")
print(f"Diferença 1 {set_categorias - outras_categorias}")
print(f"Diferença 2 {outras_categorias - set_categorias}")
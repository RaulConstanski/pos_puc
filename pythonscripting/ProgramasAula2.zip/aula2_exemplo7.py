# Tupla: é uma lista que não pode ser alterada
frutas = ["Tâmara", "Figo", "Uva"]
frutas[2] = "Melancia"
print(frutas)

# Tupla
frutas = ("Tâmara", "Figo", "Uva")
#frutas[2] = "Melancia" <-- ERRO
frutas = ("Tâmara", "Figo", "Melancia")
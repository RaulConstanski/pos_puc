presentes =  ["Dark Souls II", "Skyrim", "Vestido",     "Meias",   "Bola",  "Lego Avengers"]
convidados = ["Pedro",         "Maria",  "Tia Rosinha", "Alberto", "Amanda", "Marcelo"]

for i in range(0, len(presentes)):
    print(f"{convidados[i]} deu de presente um(a) {presentes[i]}")

# Lista de listas
# Matriz
presentes_e_convidados = [
    #   0                1
    ["Pedro",       "Dark Souls II"], # 0
    ["Maria",       "Syrim"],         # 1
    ["Tia Rosinha", "Vestido"],       # 2
    ["Alberto",     "Meias"]          # 3
]

print(presentes_e_convidados[2][1])
print(presentes_e_convidados[1][0])
print(presentes_e_convidados[3])

for i in range(0, len(presentes_e_convidados)):
    # for j in range(0, len(presentes_e_convidados[i])):
    print(f"O convidado {presentes_e_convidados[i][0]} deu o presente {presentes_e_convidados[i][1]}")

print("\nOutra forma:")
for pp in presentes_e_convidados:
    # pp = ["Pedro",       "Dark Souls II"]
    print(f"O convidado {pp[0]} deu o presente {pp[1]}")
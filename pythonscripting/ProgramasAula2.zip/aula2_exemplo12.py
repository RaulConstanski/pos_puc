from aula2_exemplo11 import saudacao

def soma(a, b) -> int:
    # a = 10
    # b = 20
    resultado = a + b
    return resultado

resultado_soma = soma(10, 20)
print(resultado_soma)

saudacao(11)
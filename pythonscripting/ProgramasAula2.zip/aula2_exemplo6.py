# Criar uma lista com os cubos dos 10 primeiros números

cubos = []
for i in range(1, 11):
    cubos.append(i ** 3)
print(cubos)

# List comprehension
print("\nOutra forma:")
# Construa uma lista onde cada elemento é i elevado ao cubo para i variando de 1 a 10
cubos = [ i ** 3 for i in range(1, 11)]
print(cubos)
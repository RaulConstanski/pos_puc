i = 0         # inicialização
while i < 10: # condição
    i = i + 1 # incremento
    print(i)

print("*" * 20)

# for i in range(1, 11): <- Omitir o passo, valor default é 1
for i in range(1, 11, 1):
    print(i, end=" ")

print("\n\n")

for par in range(0, 21, 2):
    # par = 0
    # par = 2
    # par = 4
    # par = 6
    # ...
    # par = 18
    # par = 20
    # par = 22
    print(par, end = ", ")

print("\nFim do programa")

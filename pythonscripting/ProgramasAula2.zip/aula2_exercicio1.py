# Dada uma lista contendo a precipitação e a temperatura média de cada
# um dos meses de um ano,
# Mostrar quais meses foram quentes (> 25) e
# quais meses foram secos (< 10) 

# Lista de tuplas
dados = [
    ("Janeiro", 25, 230),
    ("Fevereiro", 24, 196),
    ("Março", 24, 137),
    ("Abril", 22, 81),
    ("Maio", 19, 97),
    ("Junho", 18, 102),
    ("Julho", 18, 96),
    ("Agosto", 19, 83),
    ("Setembro", 21, 140),
    ("Outubro", 22, 147),
    ("Novembro", 23, 131),
    ("Dezembro", 24, 167)
]


# 3 listas
precipitacao = [15, 8, 12, 20, 5, 3, 7, 9, 14, 18, 22, 10] 
temperatura = [26, 30, 22, 21, 18, 16, 15, 17, 20, 23, 25, 28]  
meses = [    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]

# 2 listas: uma para os dados, outra para os meses
dados_mensais = [
    (100, 22),  # Janeiro
    (5, 28),    # Fevereiro
    (15, 30),   # Março
    (50, 25),   # Abril
    (20, 20),   # Maio
    (0, 32),    # Junho
    (10, 29),   # Julho
    (60, 27),   # Agosto
    (5, 24),    # Setembro
    (0, 26),    # Outubro
    (12, 21),   # Novembro
    (70, 23)    # Dezembro
]
nomes_meses = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio",
    "Junho", "Julho", "Agosto", "Setembro", "Outubro",
    "Novembro", "Dezembro"
]

# Dicionário, onde o valor é uma tupla
monthWeather = {
    "jan" : (31, 100),
}

dados_mensais = [
    ("Janeiro", 28, 5),
    ("Fevereiro", 30, 12),
    ("Março", 22, 20),
    ("Abril", 26, 8),
    ("Maio", 24, 15),
    ("Junho", 27, 3),
    ("Julho", 25, 9),
    ("Agosto", 29, 2),
    ("Setembro", 23, 11),
    ("Outubro", 31, 1),
    ("Novembro", 26, 4),
    ("Dezembro", 29, 0),
]
 
meses_quentes = [mes for mes, temp, _ in dados_mensais if temp > 25]
meses_secos = [mes for mes, _, precip in dados_mensais if precip < 10]
 
print("Meses quentes (> 25 graus):", meses_quentes)
print("Meses secos (< 10 mm de precipitação):", meses_secos)



dados = {
    "Janeiro": [25, 230],
    "Fevereiro": [24, 196],
    "Março": [24, 9],
    "Abril": [22, 81],
    "Maio": [19, 97],
    "Junho": [28, 102],
    "Julho": [18, 96],
    "Agosto": [29, 8],
    "Setembro": [21, 140],
    "Outubro": [32, 147],
    "Novembro": [23, 131],
    "Dezembro": [24, 167]
}
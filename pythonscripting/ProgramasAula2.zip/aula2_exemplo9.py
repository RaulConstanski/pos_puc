# Dicionário ou map
# É um conjunto de pares: chave e valor
# Não tem índice, mas tem chave
filmes_diversos = {
    "Matrix" : 10,
    "Hellboy": 8.5,
    "Parasita": 10,
    "Batman & Robin": 1.0
}

print(filmes_diversos["Hellboy"])
print(filmes_diversos)
print(filmes_diversos.keys())
print(filmes_diversos.values())

for filme in filmes_diversos:
    print(filme)

for filme, nota in filmes_diversos.items():
    print(f"Filme {filme} tem nota {nota}")

nome = input("Digite o nome do filme: ")
if nome in filmes_diversos:
    print("Nota: ", filmes_diversos[nome])
else:
    print("O filme não existe")
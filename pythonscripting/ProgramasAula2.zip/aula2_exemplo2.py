# Mostrar a tabuada do 2 

# Loop duplo
# Loops aninhados
for tabuada in range(2, 10):
    for i in range (1, 10):
        print(f"{tabuada} * {i} = {i * tabuada}")

    print()

# for i in range (1, 10):
#     print(f"3 * {i} = {i * 3}")

# print()

# for i in range (1, 10):
#     print(f"4 * {i} = {i * 4}")
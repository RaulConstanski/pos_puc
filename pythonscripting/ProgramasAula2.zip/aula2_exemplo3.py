# Presentes da Matilda
presente1 = "Dark Souls II"
presente2 = "Skyrim"
presente3 = "Vestido"
presente4 = "Meias"

# Mostrar todos os presentes que a Matilda ganhou
print(presente1, presente2, presente3, presente4)

# Coleções
# List
#                  0             1          2         3       4          5
presentes = ["Dark Souls II", "Skyrim", "Vestido", "Meias", "Bola", "Lego Avengers"]
convidados = ["Pedro", "Maria", "Tia Rosinha"]
print(presentes)
# Quantidade de elementos da lista
print("Quantidade de elementos da lista: ", len(presentes))
print("Presente da tia Rosinha: ", presentes[2])

presentes.append(200.0)
print(presentes)

presentes[0] = "Dark Souls III"
presentes[6] = 200.75

presentes.insert(1, "O Senhor dos Anéis")

# Caminhar pela lista de presentes
# Varrer a lista
# Iterar pela lista
for presente in presentes:
    print(presente)

for i in range(0, len(presentes)):
    print(f"O convidado {i+1} deu o presente {presentes[i]}")
    # print("O convidadao", i+1, "deu o presente", presentes[i] )

for i, presente in enumerate(presentes):
    print(f"O convidado {i+1} deu o presente {presente}")

print("Uso de índices:")
#                     0          1          2         3       4          5
presentes = ["Dark Souls II", "Skyrim", "Vestido", "Meias", "Bola", "Lego Avengers"]
print(presentes[3])
print("Último presente:", presentes[len(presentes)-1])
print("Último presente:", presentes[-1])
print("Penúltimo presente:", presentes[-2])

# Pedaços de lista: slicing [:]
print("Lista inteira:", presentes)
print("Lista inteira:", presentes[:])
print("Pedaço da lista", presentes[1:4])
print("Começo da lista", presentes[:2])
print("Final da lista", presentes[4:])

# Usando slicing para alterar a lista
presentes[2:4] = ["Vestido de renda", "Meias do Homem de Ferro"]
print(presentes)

presentes[2:4] = []
print(presentes)

presentes.remove("Bola")
print(presentes)

# presentes.append(["Bloodborne", "Frescobol"])
presentes.extend(["Bloodborne", "Frescobol"])
print(presentes)

presentes += ["Kit de Pintura", "Switch"]
print(presentes)

# Limpeza da lista
presentes.clear()
# presentes = []
print(presentes)

# Array ou vetor -> coleção de elementos do mesmo tipo
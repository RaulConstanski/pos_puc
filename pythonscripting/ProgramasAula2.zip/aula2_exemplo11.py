from datetime import datetime

def saudacao(hora_atual, nome = "Estranho", sobrenome=""):
    frase = ""
    if hora_atual >= 6 and hora_atual < 12:
        frase = "Bom dia"

    print(f"{frase} {nome + sobrenome}!!!")

def main():
    hora_atual = datetime.now().hour
    saudacao(11, "Fabio")
    saudacao(hora_atual, nome="Nicolas")
    saudacao(hora_atual)

if __name__ == "__main__":
    main()
